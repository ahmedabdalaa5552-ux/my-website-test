Real Estate Platform - Scaffold
--------------------------------
Structure:
- backend/: Express + Mongoose backend
- frontend/: Static HTML/JS frontend

Quick start (backend):
1. cd backend
2. npm install
3. start MongoDB locally (or export MONGO_URI)
4. set env JWT_SECRET optionally
5. npm run dev

Notes:
- This scaffold includes core endpoints and a working flow.
- Advanced media processing (OCR, voice detection) are placeholders and must be integrated separately.
- After testing, set up Nginx for reverse proxy and serve frontend statically.

Delivered by assistant.
