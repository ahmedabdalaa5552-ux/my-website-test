const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const bodyParser = require('body-parser');

const app = express();
app.use(cors());
app.use(bodyParser.json());
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// connect to mongo (use env var or default local)
const MONGO = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/realestate';
mongoose.connect(MONGO).then(()=>console.log('Mongo connected')).catch(e=>console.error(e));

// create uploads dir
const up = path.join(__dirname, 'uploads');
if(!fs.existsSync(up)) fs.mkdirSync(up, {recursive:true});

// routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/properties', require('./routes/properties'));
app.use('/api/admin', require('./routes/admin'));
app.use('/api/chat', require('./routes/chat'));
app.use('/api/settings', require('./routes/settings'));

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=>console.log('Server running on', PORT));
