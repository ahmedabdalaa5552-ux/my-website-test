Backend notes:
- Run: npm install && npm run dev
- Requires MongoDB running. Set MONGO_URI env var to Mongo connection if needed.
- JWT_SECRET env var for token signing.
- Uploads are stored in backend/uploads (ensure writable).
- This is a scaffold: PII detection, OCR and advanced media processing are placeholders to be implemented.
