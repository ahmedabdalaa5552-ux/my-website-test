const jwt = require('jsonwebtoken');
const User = require('../models/User');
module.exports = async function(req,res,next){
  const token = req.headers.authorization && req.headers.authorization.split(' ')[1];
  if(!token) return res.status(401).json({message:'No token'});
  try{
    const secret = process.env.JWT_SECRET || 'change_this_secret';
    const data = jwt.verify(token, secret);
    req.user = await User.findById(data.id).lean();
    next();
  }catch(e){ res.status(401).json({message:'Invalid token'}); }
};
