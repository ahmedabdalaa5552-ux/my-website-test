const mongoose = require('mongoose');
const UserSchema = new mongoose.Schema({
  name:String,
  phone:String,
  phoneLand:String,
  password:String,
  role:{type:String,default:'user'}, // user | admin
  identityImage:String,
  createdAt:{type:Date,default:Date.now}
});
module.exports = mongoose.model('User', UserSchema);
