const mongoose = require('mongoose');
const SettingSchema = new mongoose.Schema({
  siteName:{type:String, default:'موقع العقارات'},
  siteLogo:String,
  themeColor:{type:String,'default':'#0A5EA8'},
  showFloatingBar:{type:Boolean,default:true},
  whatsappNumber:String,
  whatsappText:{type:String,default:'تواصل بنا عبر واتساب'},
  chatText:{type:String,default:'دردشة مباشرة'},
  identityVerification:{type:String,enum:['on','off'],default:'on'},
  siteNameSize:{type:String, default:'24px'},
  siteNameColor:{type:String, default:'#000000'},
  siteNameSpacing:{type:String, default:'8px'},
  siteNameFont:{type:String, default:'sans-serif'},
  headerBgType:{type:String, default:'color'},
  headerBgValue:{type:String, default:'#ffffff'},
});
module.exports = mongoose.model('Setting', SettingSchema);
