const mongoose = require('mongoose');
const ChatRoomSchema = new mongoose.Schema({
  propertyId:{type:mongoose.Schema.Types.ObjectId, ref:'Property', default:null},
  buyerId:{type:mongoose.Schema.Types.ObjectId, ref:'User', default:null},
  adminId:{type:mongoose.Schema.Types.ObjectId, ref:'User', default:null},
  status:{type:String,enum:['open','closed'],default:'open'},
  lastMessageAt:{type:Date,default:Date.now},
  unreadForAdmin:{type:Boolean,default:true}
});
module.exports = mongoose.model('ChatRoom', ChatRoomSchema);
