const mongoose = require('mongoose');
const PropertySchema = new mongoose.Schema({
  ownerId:{type:mongoose.Schema.Types.ObjectId, ref:'User'},
  title:String,
  price:Number,
  city:String,
  district:String,
  type:String,
  offerType:String,
  area:String,
  rooms:Number,
  halls:Number,
  baths:Number,
  description:String,
  media:[{path:String, mime:String}],
  isPublished:{type:Boolean,default:false},
  requiresModeration:{type:Boolean,default:false},
  createdAt:{type:Date,default:Date.now}
});
module.exports = mongoose.model('Property', PropertySchema);
