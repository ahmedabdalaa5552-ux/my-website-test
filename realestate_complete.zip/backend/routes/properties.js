const express = require('express'); const router = express.Router();
const Property = require('../models/Property');
const auth = require('../middleware/auth');
const multer = require('multer');
const upload = multer({ dest:'uploads/' });

router.get('/list', async (req,res)=>{ const q = req.query; const page = parseInt(q.page||1); const per = 20; const skip=(page-1)*per;
  const filter={}; if(q.city) filter.city=q.city; if(q.district) filter.district=q.district; if(q.offerType) filter.offerType=q.offerType;
  const total = await Property.countDocuments(filter);
  const items = await Property.find(filter).sort({createdAt:-1}).skip(skip).limit(per).lean();
  res.json({ total, items });
});

router.post('/add', auth, upload.array('media',12), async (req,res)=>{
  try{
    const body = req.body;
    const files = req.files||[];
    const media = files.map(f=>({ path:'/uploads/'+f.filename, mime: f.mimetype }));
    const prop = new Property(Object.assign({}, body, { media, ownerId: req.user._id, isPublished: true }));
    await prop.save();
    res.json({ message:'Property created', prop });
  }catch(e){ res.status(500).json({message:e.message}); }
});

module.exports = router;
