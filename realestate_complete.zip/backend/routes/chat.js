const express = require('express'); const router = express.Router();
const auth = require('../middleware/auth'); const adminOnly = require('../middleware/adminOnly');
const ChatRoom = require('../models/ChatRoom'); const Message = require('../models/Message'); const User = require('../models/User');

router.post('/create', auth, async (req,res)=>{
  const { propertyId, initialText } = req.body;
  const admin = await User.findOne({ role:'admin' });
  if(!admin) return res.status(500).json({message:'No admin'});
  let room = await ChatRoom.findOne({ propertyId, buyerId: req.user._id });
  if(!room) room = await ChatRoom.create({ propertyId, buyerId: req.user._id, adminId: admin._id, lastMessageAt: new Date(), unreadForAdmin:true });
  if(initialText){
    const msg = await Message.create({ roomId: room._id, fromUser: req.user._id, text: initialText });
    room.lastMessageAt = msg.createdAt; room.unreadForAdmin = true; await room.save();
  }
  res.json({ room });
});

router.get('/my-rooms', auth, async (req,res)=>{ const rooms = await ChatRoom.find({ buyerId: req.user._id }).sort({lastMessageAt:-1}).lean(); res.json({ rooms }); });
router.get('/:roomId/messages', auth, async (req,res)=>{ const msgs = await Message.find({ roomId: req.params.roomId }).sort({createdAt:1}).lean(); res.json({ messages: msgs }); });
router.post('/:roomId/messages', auth, async (req,res)=>{ const { text } = req.body; const msg = await Message.create({ roomId: req.params.roomId, fromUser: req.user._id, text }); res.json({ message: msg }); });

// admin endpoints
router.get('/admin/rooms', auth, adminOnly, async (req,res)=>{ const rooms = await ChatRoom.find().sort({lastMessageAt:-1}).populate('buyerId propertyId').lean(); res.json({ rooms }); });

module.exports = router;
