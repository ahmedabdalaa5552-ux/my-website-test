const express = require('express'); const router = express.Router();
const Setting = require('../models/Setting');

router.get('/', async (req,res)=>{ const s = await Setting.findOne(); res.json(s||{}); });

module.exports = router;
