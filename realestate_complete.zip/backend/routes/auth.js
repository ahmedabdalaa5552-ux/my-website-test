const express = require('express'); const router = express.Router();
const User = require('../models/User'); const bcrypt = require('bcryptjs'); const jwt = require('jsonwebtoken');
const Setting = require('../models/Setting');
const multer = require('multer');
const upload = multer({ dest: 'uploads/' });

router.post('/register', upload.single('identityImage'), async (req,res)=>{
  try{
    const s = await Setting.findOne() || {};
    const identityMode = s.identityVerification || 'on';
    const { name, phone, phoneLand, password } = req.body;
    if(!name||!phone||!password) return res.status(400).json({message:'Missing fields'});
    if(identityMode === 'on' && !req.file) return res.status(400).json({message:'Identity required'});
    let hashed = await bcrypt.hash(password, 10);
    let u = new User({ name, phone, phoneLand, password:hashed });
    if(req.file) u.identityImage = '/uploads/' + req.file.filename;
    await u.save();
    const token = jwt.sign({ id: u._id }, process.env.JWT_SECRET || 'change_this_secret');
    res.json({ token, user: { id:u._id, name:u.name } });
  }catch(e){ console.error(e); res.status(500).json({message:e.message}); }
});

router.post('/login', async (req,res)=>{
  try{
    const { phone, password } = req.body;
    const u = await User.findOne({ phone });
    if(!u) return res.status(400).json({message:'No user'});
    const ok = await bcrypt.compare(password, u.password);
    if(!ok) return res.status(400).json({message:'Bad credentials'});
    const token = jwt.sign({ id: u._id }, process.env.JWT_SECRET || 'change_this_secret');
    res.json({ token, user:{ id:u._id, name:u.name } });
  }catch(e){ res.status(500).json({message:e.message}); }
});

module.exports = router;
