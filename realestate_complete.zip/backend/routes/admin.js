const express = require('express'); const router = express.Router();
const auth = require('../middleware/auth'); const adminOnly = require('../middleware/adminOnly');
const Setting = require('../models/Setting'); const Property = require('../models/Property');
const multer = require('multer'); const upload = multer({ dest:'uploads/' });

router.get('/settings', auth, adminOnly, async (req,res)=>{ const s = await Setting.findOne(); res.json(s||{}); });

router.post('/settings', auth, adminOnly, async (req,res)=>{
  try{
    let s = await Setting.findOne(); if(!s) s = new Setting();
    Object.assign(s, req.body);
    await s.save();
    res.json({ message:'saved', settings:s });
  }catch(e){ res.status(500).json({message:e.message}); }
});

router.post('/upload-logo', auth, adminOnly, upload.single('logo'), async (req,res)=>{
  if(!req.file) return res.status(400).json({message:'file required'});
  let s = await Setting.findOne() || new Setting();
  s.siteLogo = '/uploads/' + req.file.filename;
  await s.save();
  res.json({ message:'logo saved', url: s.siteLogo });
});

module.exports = router;
