(async function(){ const s = await (await fetch('/api/settings')).json(); if(!s.showFloatingBar) return;
const bar = document.createElement('div'); bar.style.position='fixed'; bar.style.bottom='20px'; bar.style.right='20px'; bar.style.zIndex='9999';
const wrapper = document.createElement('div'); wrapper.style.display='flex'; wrapper.style.gap='8px'; wrapper.style.background=s.themeColor||'#0A5EA8'; wrapper.style.padding='8px'; wrapper.style.borderRadius='28px'; wrapper.style.alignItems='center';
const chat = document.createElement('button'); chat.innerText = s.chatText||'دردشة مباشرة'; chat.onclick = ()=>{ const token = localStorage.getItem('token'); if(!token) return location.href='register.html'; window.location.href='admin_chat.html'; };
const wa = document.createElement('a'); wa.innerText = s.whatsappText||'تواصل بنا عبر واتساب'; wa.href = s.whatsappNumber ? 'https://wa.me/'+s.whatsappNumber : '#'; wa.target='_blank';
wrapper.appendChild(chat); wrapper.appendChild(wa); bar.appendChild(wrapper); document.body.appendChild(bar); })();
